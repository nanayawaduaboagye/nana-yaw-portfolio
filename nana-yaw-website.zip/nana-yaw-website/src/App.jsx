export default function App() {
  return (
    <div>
      <section style={{
        background: '#0f172a',
        color: 'white',
        padding: '80px 20px',
        textAlign: 'center'
      }}>
        <h1 style={{fontSize: '48px', marginBottom: '10px'}}>
          Nana Yaw Adu Aboagye
        </h1>

        <p style={{fontSize: '20px'}}>
          Researcher • Youth Advocate • Christian Leader
        </p>

        <div style={{marginTop: '30px'}}>
          <a href="https://www.linkedin.com/in/nana-yaw-adu-aboagye-5ab94a32b"
             target="_blank"
             style={buttonStyle}>
            LinkedIn
          </a>

          <a href="https://www.facebook.com/share/1EApskrQsC/?mibextid=wwXIfr"
             target="_blank"
             style={buttonStyle}>
            Facebook
          </a>

          <a href="https://youtube.com/@expeditedeffects?si=ziENUXBeIrtJh3Do"
             target="_blank"
             style={buttonStyle}>
            YouTube
          </a>
        </div>
      </section>

      <section style={sectionStyle}>
        <h2>About Me</h2>
        <p>
          I am passionate about understanding how climate variability and water scarcity
          affect tourism businesses in Northern Ghana. My interests include sustainable
          development, tourism resilience, youth empowerment, leadership, and ministry.
        </p>
      </section>

      <section style={sectionStyle}>
        <h2>Featured Research</h2>
        <p>
          <strong>Factors Influencing Employee Retention in Kumasi's Hospitality Industry</strong>
        </p>
      </section>

      <section style={sectionStyle}>
        <h2>Faith & Ministry</h2>
        <p>
          I am passionate about spreading the Gospel of Jesus Christ and serving through
          Jesus Event Ministries.
        </p>
      </section>

      <section style={sectionStyle}>
        <h2>FutureRise Foundation Ghana</h2>
        <p>
          Youth empowerment, leadership development, and community transformation.
        </p>

        <iframe
          width="100%"
          height="400"
          src="https://www.youtube.com/embed/Ka2T89xSBgo"
          title="FutureRise Foundation Workshop"
          style={{border: 'none', borderRadius: '12px', marginTop: '20px'}}
          allowFullScreen
        ></iframe>
      </section>

      <section style={sectionStyle}>
        <h2>Contact</h2>
        <p>Email: hellonanayawaduaboagye@gmail.com</p>
        <p>WhatsApp: +233 598153932</p>
      </section>
    </div>
  )
}

const sectionStyle = {
  padding: '60px 20px',
  maxWidth: '1000px',
  margin: '0 auto',
  lineHeight: '1.8'
}

const buttonStyle = {
  display: 'inline-block',
  margin: '10px',
  padding: '12px 24px',
  background: 'white',
  color: '#0f172a',
  borderRadius: '8px',
  fontWeight: 'bold'
}

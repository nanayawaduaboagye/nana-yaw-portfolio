# Nana Yaw Adu Aboagye Portfolio Website

Professional React + Vite portfolio website.

## Run locally

npm install
npm run dev

## Build

npm run build
